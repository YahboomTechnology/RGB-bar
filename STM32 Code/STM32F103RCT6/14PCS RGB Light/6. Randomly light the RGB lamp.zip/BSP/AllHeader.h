#ifndef __All_HEADER_H
#define __All_HEADER_H


#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

#include "stm32f10x.h"
#include "system_stm32f10x.h"
#include "delay.h"
#include "led.h"
#include "WS2812.h"
#include "stm32f10x_tim.h"
#include "timer.h"
#include "Adc.h"

#endif

